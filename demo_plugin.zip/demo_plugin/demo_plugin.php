<?php
/*
	Plugin Name: Demo Plugin
	Plugin URI: http://panonda.com
	Description: Demo Product Licensing system plugin.
	Author: Panonda
	Version: 1.0
	Author URI: http://panonda.com
*/

if (is_admin())
    require_once "include/plicense-activation.php";

if (is_admin()) {
    require_once "include/demo-page1.php";
    require_once "include/demo-page2.php";
}

add_action("admin_menu", "plicense_menu_setup");
function plicense_menu_setup() {
    global $PLicense_Activation;
    if ($PLicense_Activation->is_plicense_valid()) {
        add_menu_page("Demo Plugin", "Demo Plugin", "manage_options", "demo-page1", "demo_page1");
        
        add_submenu_page("demo-page1", "Demo Page1", "Demo Page1", "manage_options", "demo-page1", "demo_page1");
        add_submenu_page("demo-page1", "Demo Page2", "Demo Page2", "manage_options", "demo-page2", "demo_page2");
        add_submenu_page("demo-page1", "License", "License", "manage_options", "plicense", "plicense_activate");
    }
    else {
        add_menu_page("Demo Plugin", "Demo Plugin", "manage_options", "plicense", "plicense_activate");
    }
    
}