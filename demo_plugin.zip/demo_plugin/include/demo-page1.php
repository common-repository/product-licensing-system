<?php
function demo_page1() {
    echo '<h2>Demo Page1</h2>';
}
