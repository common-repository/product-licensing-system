<?php
function demo_page2() {
    echo '<h2>Demo Page2</h2>';
}
