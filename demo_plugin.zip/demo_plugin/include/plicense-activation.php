<?php

if (!defined('ABSPATH')) exit; // Exit if accessed directly
define('PLICENSE_PRODUCT_NAME', 'WOOPS');

if (!class_exists('PLicense_Activation')) {
    class PLicense_Activation {
        
        function is_plicense_valid() {
            $plicense_key = get_option('plicsence_key'.PLICENSE_PRODUCT_NAME);
            if (!$plicense_key) return false;

            if (false === ($value = get_transient('plicense_state'))) {
                if ($this->plicense_valid_check($plicense_key)) {
                    set_transient('plicense_state', 1, 30 * MINUTE_IN_SECONDS);
                    return true;
                }
            }
            else return true;

            return false;
        }

        function plicense_valid_check($license) {

            //$serverurl = "http://example.com/wp-content/plugins/plicensing/verify.php";
            $serverurl = "http://localhost/wp/wp_shop/wp-content/plugins/plicensing/verify.php"; //for local test

            $response = wp_remote_post($serverurl, array(
                    'method' => 'POST',
                    'timeout' => 20,
                    'redirection' => 5,
                    'httpversion' => '1.0',
                    'blocking' => true,
                    'headers' => array(),
                    'body' => array( 'domain' => $_SERVER['SERVER_NAME'], 'licensekey' => $license ),
                    'cookies' => array()
                )
            );

            if (is_wp_error($response))
               $response = '';

            $result = json_decode($response['body'], true);
            
            //avaiable 'valid' value is true, false, pending, expired
            update_option('plicsence_key_status', $result['valid']);
            update_option('plicsence_key'.PLICENSE_PRODUCT_NAME, $license);
            
            if($result['valid'] == "true")
                return true;
            else {
                delete_transient('plicense_state');
            }
            return false;
        }
    }
}
$GLOBALS['PLicense_Activation'] = new PLicense_Activation(); 
if (!function_exists('plicense_activate')) {
    function plicense_activate() {
        global $PLicense_Activation;

        if(isset($_POST['plicsence_key'])) {
            $PLicense_Activation->plicense_valid_check($_POST['plicsence_key']);
            wp_redirect(admin_url() . 'admin.php?page=plicense');
            exit;
        }
        ?>
        <div class="wrap">
        <h2>License</h2><br/>
        <form method="post" action="">
            <table class="wp-list-table widefat tags ui-sortable" style="width:400px;">
                <thead><tr><th colspan="2">
                <?php 
                if(get_option('plicsence_key'.$PLicense_Activation->product_name) != '')
                    echo 'Your Installed License Code is';
                else
                    echo 'Please Input Your License Code to activate the plugin.';
                ?>
                </th></tr></thead>
                <tbody>
                    <tr>
                      <td valign="top"><br/><label for="license">License Key:</label></td>
                      <td>
                        <br/><input class="textfield" name="plicsence_key" size="50" type="text" id="plicsence_key" value="<?php echo get_option('plicsence_key'.PLICENSE_PRODUCT_NAME); ?>" /><br/>
                        <br/><input type="submit" value="Activate" class="button-primary" id="plicense_activate" name="plicense_activate">&nbsp;&nbsp;&nbsp;
                        <?php 
                        //true, false, pending, expired
                        switch (get_option('plicsence_key_status')) {
                            case 'true': echo '<span style="color:green;">License key is activated.</span>'; break;
                            case 'false': echo '<span style="color:red;">License key is not valid.</span>'; break;
                            case 'pending': echo '<span style="color:red;">License key is pending.</span>'; break;
                            case 'expired': echo '<span style="color:red;">License key is expired.</span>'; break;
                        }
                        ?>
                      </td>
                    </tr>
                </tbody>
              </table>
          </form>
        </div>
    <?php 
    }
}